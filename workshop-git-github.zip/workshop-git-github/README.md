# Workshop Git & GitHub — Reychika Marsya Adisti

## Deskripsi Repository
Repository ini berisi website sederhana dan catatan pembelajaran dari workshop **Building with AI, Managing Change with GitHub**. Website dibuat menggunakan HTML, CSS, dan JavaScript murni.

## Tujuan Repository
Repository ini dibuat sebagai dokumentasi hasil workshop sekaligus latihan membuat web application sederhana. Isinya membantu mengingat materi Prompt Engineering, pengenalan Git dan GitHub, alur kerja Git, serta dasar pengelolaan proyek dan perubahan kode.

## Informasi Workshop
Workshop membahas cara memanfaatkan AI untuk membantu proses pembuatan aplikasi serta cara menggunakan Git dan GitHub untuk mengelola perubahan dan mendukung kolaborasi. Salah satu contoh kegiatan yang diperkenalkan adalah membuat aplikasi sederhana, memasukkannya ke Git, lalu melakukan commit dan push ke GitHub.

## Materi yang Dipelajari
1. **Prompt Engineering** — menyusun instruksi yang jelas agar AI menghasilkan jawaban sesuai kebutuhan.
2. **Struktur prompt** — menggunakan Role, Task, Context, dan Format.
3. **Pengenalan Git** — memahami Git sebagai version control system untuk melacak perubahan file.
4. **Git vs GitHub** — Git mengelola perubahan proyek, sedangkan GitHub menjadi platform online untuk menyimpan repository Git dan berkolaborasi.
5. **Git Workflow** — memahami working directory, staging area, commit, dan Git directory.
6. **Git dan VS Code Setup** — memeriksa instalasi serta mengatur identitas Git.
7. **Repository dan SSH Key** — membuat atau menyalin repository dan mengenal autentikasi SSH ke GitHub.
8. **Commit dan sinkronisasi** — menggunakan perintah dasar untuk menyimpan serta mengirim perubahan.

## Catatan Perintah Git

| Perintah | Kegunaan |
|---|---|
| `git init` | Memulai repository Git baru. |
| `git add .` | Menambahkan perubahan file ke staging area. |
| `git commit -m "pesan"` | Menyimpan perubahan ke riwayat repository. |
| `git remote add origin URL` | Menghubungkan repository lokal dengan remote. |
| `git push origin main` | Mengirim commit ke branch main di remote. |
| `git pull origin main` | Mengambil dan menggabungkan perubahan dari remote. |
| `git clone URL` | Menyalin repository dari sumber remote. |

## Poin Penting yang Dipelajari
- Prompt yang spesifik dan memiliki konteks dapat membantu AI memberikan hasil yang lebih relevan.
- Git dan GitHub memiliki fungsi berbeda, tetapi dapat digunakan bersama.
- Staging area menjadi tempat memilih perubahan sebelum dibuat menjadi commit.
- Commit menyimpan catatan perubahan, sedangkan push mengirim perubahan ke repository remote.
- GitHub membantu menyimpan proyek secara online dan mendukung kolaborasi.

## Struktur File

```text
workshop-git-github/
├── index.html   # Struktur dan isi halaman website
├── style.css    # Tampilan, warna, layout, dan responsive design
├── script.js    # Interaksi tombol ringkasan dan checklist progres
└── README.md    # Dokumentasi repository dan rangkuman workshop
```

## Cara Menjalankan Aplikasi
1. Download atau clone repository ini ke komputer.
2. Buka folder `workshop-git-github` menggunakan Visual Studio Code atau file manager.
3. Buka file `index.html` di browser (misalnya Chrome).
4. Klik tombol **Baca ringkasan** pada kartu materi untuk membuka atau menutup penjelasan.
5. Centang daftar poin penting untuk melihat progres belajar.

Tidak perlu menginstal library atau dependency tambahan. Website menggunakan HTML, CSS, dan vanilla JavaScript. Font dari Google Fonts hanya bersifat tambahan; jika tidak tersedia, website tetap menggunakan font cadangan.

## Cara Menguji Interaksi
- Klik **Baca ringkasan** pada salah satu kartu materi. Ringkasan seharusnya muncul dan tombol berubah menjadi **Tutup ringkasan**.
- Klik tombol yang sama lagi. Ringkasan seharusnya tertutup.
- Centang satu atau beberapa poin pada bagian **Poin penting workshop**. Angka progres dan panjang progress bar seharusnya ikut berubah.
- Hapus centang. Progres seharusnya berkurang kembali.
- Ubah ukuran jendela browser atau buka dari ponsel untuk memeriksa tampilan responsif.

---

Dibuat sebagai dokumentasi pembelajaran workshop oleh **Reychika Marsya Adisti**.
